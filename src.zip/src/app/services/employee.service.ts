import { Injectable } from '@angular/core';
import { Employee } from '../model/Employee';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
    providedIn:'root'
})
export class EmployeeService{
    employeeList:Employee[];
    private baseUrl= 'http://localhost:8081/api/employee';

    employee: Employee;
    constructor(private http:HttpClient,private router: Router) { }
  

    addEmployee(employee:Employee): Observable<Object>{
        
        return this.http.post('http://localhost:8081/api/employee' +`/addEmployee`,employee);
    }
  

    updateEmployee(employee: Employee): Observable<Object> {
        return this.http.post('http://localhost:8081/api/employee' + `/updateEmployee`, employee);
      }

    getAllEmployeeDetail(){
        return this.http.get<Employee[]>('http://localhost:8081/api/employee'+`/getAllEmployeeDetail`);
    }

    deleteEmployee(employeeId):any
    {
        let params = new HttpParams();
        params = params.set('employeeId',employeeId);
        return this.http.delete('http://localhost:8081/api/employee'+`/deleteEmployee`,{params:params});
    }


    getEmployeeById(employeeId){
          let params = new HttpParams();
          params = params.set('employeeId',employeeId);
          return this.http.get<Employee[]>('http://localhost:8081/api/employee'+`/getDetailOfEmployee`,{params:params});
    }





}