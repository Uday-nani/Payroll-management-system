import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
    providedIn:'root'
})
export class Salary{
    private baseUrl= 'http://localhost:8081/api/salary';

    salary: Salary;
    constructor(private http:HttpClient,private router: Router) { }
  

    addSalary(salary:Salary): Observable<Object>{
        
        return this.http.post('http://localhost:8081/api/salary' +`/addSalary`,salary);
    }
  

    updateSalary(salary: Salary): Observable<Object> {
        return this.http.post('http://localhost:8081/api/salary' + `/updateSalary`, salary);
      }

    getAllSalaryDetail(){
        return this.http.get<Salary[]>('http://localhost:8081/api/salary'+`/getAllSalaryDetail`);
    }

    deleteSalary(employeeId):any
    {
        let params = new HttpParams();
        params = params.set('employeeId',employeeId);
        return this.http.delete('http://localhost:8081/api/salary'+`/deleteSalary`,{params:params});
    }


    getSalaryOfEmployee(employeeId){
          let params = new HttpParams();
          params = params.set('employeeId',employeeId);
          return this.http.get<Salary[]>('http://localhost:8081/api/salary'+`/getSalaryOfEmployee`,{params:params});
    }




}