import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
    providedIn:'root'
})
export class AuthenticationService{
    public username;
    private baseUrl = 'http://localhost:8081/api/admin';
    private adminDetails = new BehaviorSubject(null);
    constructor(private http: HttpClient) { }
  
    login(username, password): Observable<any> {
      let params = new HttpParams();
      params = params.set('username', username);
      params = params.set('password', password);
      return this.http.get(`${this.baseUrl}` + `/find`, { params: params });
    }
  
    sendAdminDetail(data) {
      //console.log("admin details")
      this.adminDetails.next(data);
      console.log(this.adminDetails);
    }
  
    getAdminDetail() {
      return this.adminDetails.asObservable();
    }
}