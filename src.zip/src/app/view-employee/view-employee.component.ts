import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/Employee';
import { Salary } from '../model/Salary';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  employeeArr: Employee[];
  sal:Salary;
  constructor() { }

  ngOnInit(): void {
    this.employeeArr=[{eid:1234,ename:"Tabassum",username:"tabshaik",password:"",role:"junior",department:"Hr",deg:"associate",salary:this.sal}];
  
  }
}
