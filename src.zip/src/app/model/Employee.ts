import { Salary } from './Salary';

export class Employee{
    eid:number;
    ename:String;
    username:String;
    password:String;
    deg:String;
    department:String;
    role:String;
    salary:Salary;

}