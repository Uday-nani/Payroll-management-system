import { Employee } from './employee';

export class Salary{
    sid:number;
    salary:number;
    grade:String;
    month:String;
    emp:Employee;
}