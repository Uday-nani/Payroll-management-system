import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form = new FormGroup({
    UserName: new FormControl('',Validators.required),
    password: new FormControl('',[Validators.required,Validators.minLength(6)])
  })

  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(){
    alert(JSON.stringify(this.form.value))
  }

}
